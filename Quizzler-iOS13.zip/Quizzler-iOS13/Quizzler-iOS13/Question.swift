//
//  Question.swift
//  Quizzler-iOS13
//
//  Created by Shane Hall on 3/28/25.
//  Copyright © 2025 The App Brewery. All rights reserved.
//

import Foundation


struct Question {
    let text: String
    let answers: String
   
    init(q: String, a: String) {
        text = q
        answers = a
    }
    
    
}
